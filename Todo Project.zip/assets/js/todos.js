// Check Off Specific Todos By Clicking - HARD VERSION
// $("li").click(function(){
// 	//if li is gray	turn it black
// 	if($(this).css("color") === "rgb(128, 128, 128)"){
// 		$(this).css({
// 			color: "black",
// 			textDecoration: "none"
// 		});
// 	}
// 	//else turn it gray1
// 	else{
// 		$(this).css({
// 			color: "gray",
// 			textDecoration: "line-through"
// 		});
// 	}	
// });

//Check Off Specific Todos By Clicking - EASY VERSION
$("ul").on("click", "li", function(){
	$(this).toggleClass("completed");
});

//Click on X to Delete Todos

$("ul").on("click", "span", function(event){
	$(this).parent().fadeOut(500, function(){
		$(this).remove();
	});
	event.stopPropagation();
});

// Add new To Do

$("input[type='text']").keypress(function(event){
	if(event.which === 13/*ENTER Key is 13*/){
		//Grabbing new todo text from input
		var todoText = $(this).val();
		$(this).val("");
		//Create a new li and add to ul
		$("ul").append("<li><span><i class='fa fa-trash'></i></span> " + todoText + "</li>")
	}
});

$(".fa-plus").click(function(){
	$("input[type='text']").fadeToggle();
});